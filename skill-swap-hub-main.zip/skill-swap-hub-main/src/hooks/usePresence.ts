import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

// Global presence channel — every signed-in user joins on app load,
// so we can tell whether any given userId is online right now.
const CHANNEL_NAME = "global-presence";

let channel: ReturnType<typeof supabase.channel> | null = null;
let onlineSet = new Set<string>();
const listeners = new Set<(s: Set<string>) => void>();

const notify = () => {
  const snapshot = new Set(onlineSet);
  listeners.forEach((l) => l(snapshot));
};

const ensureChannel = (userId: string) => {
  if (channel) return;
  channel = supabase.channel(CHANNEL_NAME, {
    config: { presence: { key: userId } },
  });
  channel
    .on("presence", { event: "sync" }, () => {
      const state = channel!.presenceState();
      onlineSet = new Set(Object.keys(state));
      notify();
    })
    .subscribe(async (status) => {
      if (status === "SUBSCRIBED") {
        await channel!.track({ online_at: new Date().toISOString() });
      }
    });
};

export const usePresenceTracker = () => {
  const { user } = useAuth();
  useEffect(() => {
    if (!user?.id) return;
    ensureChannel(user.id);
    return () => {
      // keep channel alive for the whole session
    };
  }, [user?.id]);
};

export const useIsOnline = (userId?: string | null) => {
  const [online, setOnline] = useState(false);
  useEffect(() => {
    if (!userId) {
      setOnline(false);
      return;
    }
    const handler = (s: Set<string>) => setOnline(s.has(userId));
    listeners.add(handler);
    handler(onlineSet);
    return () => {
      listeners.delete(handler);
    };
  }, [userId]);
  return online;
};
