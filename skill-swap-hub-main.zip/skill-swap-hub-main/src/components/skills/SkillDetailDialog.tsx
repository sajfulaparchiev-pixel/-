import { useState } from "react";
import { Star, Clock, Video, MapPin, MessageCircle, Phone } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import UserAvatar from "@/components/profile/UserAvatar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Skill } from "./SkillCard";
import ChatDialog from "@/components/chat/ChatDialog";
import { useAuth } from "@/contexts/AuthContext";
import { useSkills } from "@/contexts/SkillsContext";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

interface SkillDetailDialogProps {
  skill: Skill | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const formatConfig: Record<string, { label: string }> = {
  online: { label: "Онлайн" },
  offline: { label: "Офлайн" },
  both: { label: "Любой формат" },
};

const SkillDetailDialog = ({ skill, open, onOpenChange }: SkillDetailDialogProps) => {
  const [chatOpen, setChatOpen] = useState(false);
  const { user } = useAuth();
  const { requestExchange } = useSkills();
  const navigate = useNavigate();

  if (!skill) return null;

  const ratingDisplay = skill.user.rating > 0 ? skill.user.rating.toFixed(1) : "—";

  const handleWriteClick = () => {
    if (!user) {
      toast.error("Войдите в аккаунт, чтобы написать сообщение");
      onOpenChange(false);
      navigate("/auth");
      return;
    }
    setChatOpen(true);
  };

  const handleExchangeClick = async () => {
    if (!user) {
      toast.error("Войдите в аккаунт, чтобы предложить обмен");
      onOpenChange(false);
      navigate("/auth");
      return;
    }
    await requestExchange(skill);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-xl">{skill.title}</DialogTitle>
        </DialogHeader>

        {/* User Info */}
        <div className="flex items-center gap-4 p-4 bg-secondary/50 rounded-xl">
          <UserAvatar
            avatarId={skill.user.avatar}
            userInitials={skill.user.name.slice(0, 2).toUpperCase()}
            size="h-14 w-14"
            textSize="text-lg"
          />
          <div className="flex-1">
            <p className="font-semibold text-foreground text-lg">{skill.user.name}</p>
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-accent fill-accent" />
                <span className="font-medium">{ratingDisplay}</span>
              </div>
              <span>•</span>
              <span>{skill.user.sessionsCount} сессий проведено</span>
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="space-y-3">
          <h4 className="font-medium text-foreground">Описание</h4>
          <p className="text-muted-foreground leading-relaxed">{skill.description}</p>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary" className="gap-1">
            {skill.format === "online" ? (
              <>
                <Video className="w-3 h-3" />
                Онлайн
              </>
            ) : skill.format === "offline" ? (
              <>
                <MapPin className="w-3 h-3" />
                Офлайн
              </>
            ) : (
              "Любой формат"
            )}
          </Badge>
          <Badge variant="secondary" className="gap-1">
            <Clock className="w-3 h-3" />
            {skill.duration} мин
          </Badge>
          <Badge variant="outline">{skill.category}</Badge>
        </div>

        {/* Wanted Skills */}
        {skill.wantedSkills && skill.wantedSkills.length > 0 && (
          <div className="space-y-2 pt-2 border-t border-border">
            <p className="text-sm font-medium text-foreground">Хочет изучить:</p>
            <div className="flex flex-wrap gap-2">
              {skill.wantedSkills.map((s) => (
                <span
                  key={s}
                  className="text-sm px-3 py-1.5 rounded-lg bg-primary/10 text-primary font-medium"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4">
          <Button variant="outline" className="flex-1 gap-2" onClick={handleWriteClick}>
            <MessageCircle className="w-4 h-4" />
            Написать
          </Button>
          <Button variant="hero" className="flex-1 gap-2" onClick={handleExchangeClick}>
            <Phone className="w-4 h-4" />
            Предложить обмен
          </Button>
        </div>
      </DialogContent>

      <ChatDialog
        open={chatOpen}
        onOpenChange={setChatOpen}
        recipientName={skill.user.name}
        recipientAvatar={skill.user.avatar}
        recipientId={skill.userId}
      />
    </Dialog>
  );
};

export default SkillDetailDialog;
