import { motion } from "framer-motion";
import { Search, SlidersHorizontal } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface SkillFiltersProps {
  onSearch?: (query: string) => void;
  onCategoryChange?: (category: string) => void;
}

const SkillFilters = ({ onSearch, onCategoryChange }: SkillFiltersProps) => {
  const { t } = useLanguage();
  const [activeCategory, setActiveCategory] = useState("Все");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [filterOpen, setFilterOpen] = useState(false);

  const categories = [
    { key: "Все", label: t("all") },
    { key: "Программирование", label: t("programming") },
    { key: "Дизайн", label: t("design") },
    { key: "Музыка", label: t("music") },
    { key: "Языки", label: t("languages") },
    { key: "Фитнес", label: t("fitness") },
    { key: "Бизнес", label: t("business") },
    { key: "Искусство", label: t("art") },
  ];

  const handleCategoryClick = (category: string) => {
    setActiveCategory(category);
    onCategoryChange?.(category);
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    onSearch?.(e.target.value);
  };

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            placeholder={t("searchSkills")}
            value={searchQuery}
            onChange={handleSearch}
            className="pl-10 h-12 rounded-xl border-border/50 bg-secondary/50 focus:bg-background"
          />
        </div>
        <Sheet open={filterOpen} onOpenChange={setFilterOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="h-12 w-12 rounded-xl">
              <SlidersHorizontal className="w-5 h-5" />
            </Button>
          </SheetTrigger>
          <SheetContent>
            <SheetHeader>
              <SheetTitle>{t("search")}</SheetTitle>
            </SheetHeader>
            <div className="space-y-6 mt-6">
              <div className="space-y-3">
              <Label className="text-base font-medium">Сортировка</Label>
                <RadioGroup value={sortBy} onValueChange={setSortBy} className="space-y-2">
                  <Label htmlFor="sort-newest" className="flex items-center gap-3 p-3 rounded-lg border cursor-pointer hover:bg-secondary/50">
                    <RadioGroupItem value="newest" id="sort-newest" />
                    <span>Сначала новые</span>
                  </Label>
                  <Label htmlFor="sort-popular" className="flex items-center gap-3 p-3 rounded-lg border cursor-pointer hover:bg-secondary/50">
                    <RadioGroupItem value="popular" id="sort-popular" />
                    <span>Самые популярные</span>
                  </Label>
                  <Label htmlFor="sort-rating" className="flex items-center gap-3 p-3 rounded-lg border cursor-pointer hover:bg-secondary/50">
                    <RadioGroupItem value="rating" id="sort-rating" />
                    <span>По рейтингу</span>
                  </Label>
                </RadioGroup>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Categories */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide"
      >
        {categories.map((category) => (
          <Badge
            key={category.key}
            variant={activeCategory === category.key ? "default" : "secondary"}
            className={`cursor-pointer whitespace-nowrap px-4 py-2 text-sm font-medium transition-all hover:scale-105 ${
              activeCategory === category.key
                ? "gradient-hero border-transparent"
                : "hover:bg-secondary/80"
            }`}
            onClick={() => handleCategoryClick(category.key)}
          >
            {category.label}
          </Badge>
        ))}
      </motion.div>
    </div>
  );
};

export default SkillFilters;
