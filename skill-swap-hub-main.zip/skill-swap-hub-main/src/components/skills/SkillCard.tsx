import { useState } from "react";
import { motion } from "framer-motion";
import { Star, Clock, Video, MapPin, ArrowRight, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import UserAvatar from "@/components/profile/UserAvatar";
import SkillDetailDialog from "./SkillDetailDialog";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useSkills } from "@/contexts/SkillsContext";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export interface Skill {
  id: string;
  title: string;
  description: string;
  level: "beginner" | "intermediate" | "expert";
  format: "online" | "offline" | "both";
  duration: number;
  category: string;
  userId?: string;
  user: {
    name: string;
    avatar?: string;
    rating: number;
    sessionsCount: number;
  };
  wantedSkills?: string[];
}

interface SkillCardProps {
  skill: Skill;
  index?: number;
  isOwner?: boolean;
}

const levelLabels: Record<string, string> = {
  beginner: "Начинающий",
  intermediate: "Средний", 
  expert: "Эксперт",
};

const SkillCard = ({ skill, index = 0, isOwner = false }: SkillCardProps) => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const { deleteSkill } = useSkills();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.4 }}
      whileHover={{ y: -4 }}
      className="group bg-card rounded-2xl border border-border/50 p-5 shadow-soft hover:shadow-card transition-all duration-300 relative"
    >
      {/* Delete button for owner */}
      {isOwner && (
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-3 right-3 h-8 w-8 text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Удалить навык?</AlertDialogTitle>
              <AlertDialogDescription>
                Навык «{skill.title}» будет удалён безвозвратно.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Отмена</AlertDialogCancel>
              <AlertDialogAction onClick={() => deleteSkill(skill.id)}>
                Удалить
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      {/* User Info */}
      {skill.userId ? (
        <Link
          to={`/user/${skill.userId}`}
          className="flex items-center gap-3 mb-4 group/user rounded-lg -m-1 p-1 hover:bg-secondary/50 transition-colors"
          onClick={(e) => e.stopPropagation()}
        >
          <UserAvatar
            avatarId={skill.user.avatar}
            userInitials={skill.user.name.slice(0, 2).toUpperCase()}
          />
          <div className="flex-1 min-w-0">
            <p className="font-medium text-foreground truncate group-hover/user:text-primary transition-colors">
              {skill.user.name}
            </p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Star className="w-3.5 h-3.5 text-accent fill-accent" />
              <span>{skill.user.rating > 0 ? skill.user.rating.toFixed(1) : "—"}</span>
              <span>•</span>
              <span>{skill.user.sessionsCount} сессий</span>
            </div>
          </div>
        </Link>
      ) : (
        <div className="flex items-center gap-3 mb-4">
          <UserAvatar
            avatarId={skill.user.avatar}
            userInitials={skill.user.name.slice(0, 2).toUpperCase()}
          />
          <div className="flex-1 min-w-0">
            <p className="font-medium text-foreground truncate">{skill.user.name}</p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Star className="w-3.5 h-3.5 text-accent fill-accent" />
              <span>{skill.user.rating > 0 ? skill.user.rating.toFixed(1) : "—"}</span>
              <span>•</span>
              <span>{skill.user.sessionsCount} сессий</span>
            </div>
          </div>
        </div>
      )}

      {/* Skill Info */}
      <div className="space-y-3">
        <div>
          <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
            {skill.title}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
            {skill.description}
          </p>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary" className="gap-1">
            {skill.format === "online" ? (
              <>
                <Video className="w-3 h-3" />
                Онлайн
              </>
            ) : skill.format === "offline" ? (
              <>
                <MapPin className="w-3 h-3" />
                Офлайн
              </>
            ) : (
              "Любой формат"
            )}
          </Badge>
          <Badge variant="secondary" className="gap-1">
            <Clock className="w-3 h-3" />
            {skill.duration} мин
          </Badge>
        </div>

        {/* Wanted Skills */}
        {skill.wantedSkills && skill.wantedSkills.length > 0 && (
          <div className="pt-3 border-t border-border/50">
            <p className="text-xs text-muted-foreground mb-2">Хочет изучить:</p>
            <div className="flex flex-wrap gap-1.5">
              {skill.wantedSkills.slice(0, 3).map((s) => (
                <span
                  key={s}
                  className="text-xs px-2 py-1 rounded-md bg-secondary text-secondary-foreground"
                >
                  {s}
                </span>
              ))}
              {skill.wantedSkills.length > 3 && (
                <span className="text-xs px-2 py-1 text-muted-foreground">
                  +{skill.wantedSkills.length - 3}
                </span>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Action Button */}
      <Button
        variant="ghost"
        className="w-full mt-4 group-hover:bg-primary/5 group-hover:text-primary"
        onClick={() => setDialogOpen(true)}
      >
        Подробнее
        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
      </Button>

      <SkillDetailDialog
        skill={skill}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
      />
    </motion.div>
  );
};

export default SkillCard;
