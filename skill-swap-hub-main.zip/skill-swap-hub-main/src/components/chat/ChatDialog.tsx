import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import {
  Send,
  Paperclip,
  X,
  Trash2,
  MoreVertical,
  Check,
  CheckCheck,
  Image as ImageIcon,
  Download,
  Smile,
  Phone,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import VideoCallDialog from "@/components/calls/VideoCallDialog";
import { useIsOnline } from "@/hooks/usePresence";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface DBMessage {
  id: string;
  conversation_id: string;
  sender_id: string;
  recipient_id: string;
  sender_name: string;
  text: string;
  file_name: string | null;
  file_type: string | null;
  file_data: string | null;
  deleted_for_sender: boolean;
  deleted_for_all: boolean;
  read_at: string | null;
  created_at: string;
}

interface ChatDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  recipientName: string;
  recipientAvatar?: string;
  recipientId?: string;
}

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
const MAX_IMAGE_DIMENSION = 1600; // for client-side compression
const QUICK_EMOJI = ["👍", "❤️", "😂", "🔥", "🎉", "🙏", "👏", "😍"];

const EMOJI_CATEGORIES: Record<string, string[]> = {
  "Смайлы": ["😀","😃","😄","😁","😆","😅","🤣","😂","🙂","🙃","😉","😊","😇","🥰","😍","🤩","😘","😗","😚","😙","🥲","😋","😛","😜","🤪","😝","🤑","🤗","🤭","🤫","🤔","🤐","🤨","😐","😑","😶","😏","😒","🙄","😬","🤥","😌","😔","😪","🤤","😴","😷","🤒","🤕","🤧","🥵","🥶","🥴","😵","🤯","🤠","🥳","😎","🤓","🧐","😕","😟","🙁","☹️","😮","😯","😲","😳","🥺","😦","😧","😨","😰","😥","😢","😭","😱","😖","😣","😞","😓","😩","😫","🥱","😤","😡","😠","🤬","😈","👿","💀","💩","🤡"],
  "Жесты": ["👍","👎","👌","✌️","🤞","🤟","🤘","🤙","👈","👉","👆","👇","☝️","✋","🤚","🖐","🖖","👋","🤝","🙏","💪","🦾","✍️","💅","👏","🙌","👐","🤲","🫶","🫰","🫵","🫱","🫲","🫳","🫴"],
  "Сердца": ["❤️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","❣️","💕","💞","💓","💗","💖","💘","💝","💟","♥️","💌"],
  "Огонь": ["🔥","✨","⭐","🌟","💫","⚡","💥","💯","🎉","🎊","🎁","🏆","🥇","🥈","🥉","🎯","💎","👑","🚀","💡","🎵","🎶"],
  "Еда": ["🍕","🍔","🍟","🌭","🥪","🌮","🌯","🥗","🍿","🍩","🍪","🎂","🍰","🧁","🍫","🍬","🍭","☕","🍵","🥤","🍺","🍷","🍾","🥂"],
  "Природа": ["🌸","🌺","🌻","🌼","🌷","🌹","🌱","🌿","☘️","🍀","🍃","🌳","🌴","🌵","🌞","🌝","🌚","🌜","🌛","🌙","⭐","☁️","🌈","☀️","🌧","⛈","🌩","❄️","☃️","🌊","🔥"],
};

const makeConversationId = (a: string, b: string) =>
  a < b ? `${a}_${b}` : `${b}_${a}`;

// Compress image to JPEG/WebP via canvas to keep payload small
const compressImage = (file: File): Promise<{ data: string; type: string; name: string }> =>
  new Promise((resolve, reject) => {
    const img = new Image();
    const reader = new FileReader();
    reader.onload = () => {
      img.onload = () => {
        let { width, height } = img;
        if (width > MAX_IMAGE_DIMENSION || height > MAX_IMAGE_DIMENSION) {
          const ratio = Math.min(
            MAX_IMAGE_DIMENSION / width,
            MAX_IMAGE_DIMENSION / height
          );
          width = Math.round(width * ratio);
          height = Math.round(height * ratio);
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("Canvas not supported"));
        ctx.drawImage(img, 0, 0, width, height);
        const data = canvas.toDataURL("image/webp", 0.85);
        resolve({ data, type: "image/webp", name: file.name.replace(/\.[^.]+$/, ".webp") });
      };
      img.onerror = () => reject(new Error("Не удалось обработать изображение"));
      img.src = reader.result as string;
    };
    reader.onerror = () => reject(new Error("Не удалось прочитать файл"));
    reader.readAsDataURL(file);
  });

const ChatDialog = ({
  open,
  onOpenChange,
  recipientName,
  recipientAvatar,
  recipientId,
}: ChatDialogProps) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<DBMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [pendingFile, setPendingFile] = useState<{
    name: string;
    type: string;
    data: string;
    sizeKb: number;
  } | null>(null);
  const [sending, setSending] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [hiddenIds, setHiddenIds] = useState<string[]>([]);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [showEmoji, setShowEmoji] = useState(false);
  const [emojiTab, setEmojiTab] = useState<string>("Смайлы");
  const [callOpen, setCallOpen] = useState(false);
  const isRecipientOnline = useIsOnline(recipientId);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const conversationId = useMemo(() => {
    if (!user || !recipientId) return null;
    return makeConversationId(user.id, recipientId);
  }, [user?.id, recipientId]);

  const senderName =
    (user?.user_metadata as any)?.user_name ||
    user?.email?.split("@")[0] ||
    "Пользователь";

  // Load hidden ids when conversation changes
  useEffect(() => {
    if (!conversationId) return;
    try {
      const h = JSON.parse(
        localStorage.getItem(`chat_hidden_${conversationId}`) || "[]"
      );
      setHiddenIds(Array.isArray(h) ? h : []);
    } catch {
      setHiddenIds([]);
    }
  }, [conversationId]);

  // Load messages + subscribe to realtime
  useEffect(() => {
    if (!open || !conversationId || !user) return;

    let active = true;
    (async () => {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("conversation_id", conversationId)
        .order("created_at", { ascending: true });
      if (!active) return;
      if (error) {
        toast.error("Не удалось загрузить чат");
        return;
      }
      setMessages((data as DBMessage[]) || []);

      const unreadIds = (data || [])
        .filter((m: any) => m.recipient_id === user.id && !m.read_at)
        .map((m: any) => m.id);
      if (unreadIds.length) {
        await supabase
          .from("messages")
          .update({ read_at: new Date().toISOString() })
          .in("id", unreadIds);
      }
    })();

    const channel = supabase
      .channel(`messages-${conversationId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "messages",
          filter: `conversation_id=eq.${conversationId}`,
        },
        (payload) => {
          if (payload.eventType === "INSERT") {
            const m = payload.new as DBMessage;
            setMessages((prev) =>
              prev.some((x) => x.id === m.id) ? prev : [...prev, m]
            );
            if (m.recipient_id === user.id) {
              supabase
                .from("messages")
                .update({ read_at: new Date().toISOString() })
                .eq("id", m.id);
            }
          } else if (payload.eventType === "UPDATE") {
            const m = payload.new as DBMessage;
            setMessages((prev) => prev.map((x) => (x.id === m.id ? m : x)));
          } else if (payload.eventType === "DELETE") {
            const m = payload.old as DBMessage;
            setMessages((prev) => prev.filter((x) => x.id !== m.id));
          }
        }
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [open, conversationId, user?.id]);

  useEffect(() => {
    if (scrollRef.current) {
      const viewport = scrollRef.current.querySelector(
        "[data-radix-scroll-area-viewport]"
      ) as HTMLElement | null;
      if (viewport) {
        requestAnimationFrame(() => {
          viewport.scrollTop = viewport.scrollHeight;
        });
      }
    }
  }, [messages, pendingFile]);

  // Auto-resize textarea
  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 120) + "px";
  }, [newMessage]);

  const handleSend = useCallback(async () => {
    if (!user || !recipientId || !conversationId) {
      toast.error("Войдите, чтобы отправить сообщение");
      return;
    }
    const text = newMessage.trim();
    if (!text && !pendingFile) return;
    if (text.length > 4000) {
      toast.error("Сообщение слишком длинное (макс. 4000 символов)");
      return;
    }

    setSending(true);
    const { error } = await supabase.from("messages").insert({
      conversation_id: conversationId,
      sender_id: user.id,
      recipient_id: recipientId,
      sender_name: senderName,
      text,
      file_name: pendingFile?.name ?? null,
      file_type: pendingFile?.type ?? null,
      file_data: pendingFile?.data ?? null,
    });
    setSending(false);
    if (error) {
      toast.error("Не удалось отправить: " + error.message);
      return;
    }
    setNewMessage("");
    setPendingFile(null);
    setShowEmoji(false);
  }, [newMessage, pendingFile, user, recipientId, conversationId, senderName]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileSelect = async (
    e: React.ChangeEvent<HTMLInputElement>,
    forceImage = false
  ) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;

    if (file.size > MAX_FILE_SIZE) {
      toast.error(
        `Файл слишком большой (${(file.size / 1024 / 1024).toFixed(1)} МБ). Максимум 10 МБ.`
      );
      return;
    }

    try {
      const isImage = forceImage || file.type.startsWith("image/");
      if (isImage) {
        const compressed = await compressImage(file);
        const sizeKb = Math.round((compressed.data.length * 0.75) / 1024);
        setPendingFile({ ...compressed, sizeKb });
      } else {
        const reader = new FileReader();
        reader.onload = () => {
          setPendingFile({
            name: file.name,
            type: file.type || "application/octet-stream",
            data: reader.result as string,
            sizeKb: Math.round(file.size / 1024),
          });
        };
        reader.onerror = () => toast.error("Не удалось прочитать файл");
        reader.readAsDataURL(file);
      }
    } catch (err: any) {
      toast.error(err.message || "Ошибка обработки файла");
    }
  };

  const deleteForMe = async (m: DBMessage) => {
    if (!user || !conversationId) return;
    if (m.sender_id === user.id) {
      await supabase
        .from("messages")
        .update({ deleted_for_sender: true })
        .eq("id", m.id);
    } else {
      const next = Array.from(new Set([...hiddenIds, m.id]));
      setHiddenIds(next);
      localStorage.setItem(`chat_hidden_${conversationId}`, JSON.stringify(next));
    }
  };

  const deleteForAll = async (m: DBMessage) => {
    if (!user || m.sender_id !== user.id) return;
    const { error } = await supabase.from("messages").delete().eq("id", m.id);
    if (error) toast.error("Не удалось удалить");
  };

  const clearChat = async () => {
    if (!user || !conversationId) return;
    const myIds = messages.filter((m) => m.sender_id === user.id).map((m) => m.id);
    if (myIds.length) {
      await supabase.from("messages").delete().in("id", myIds);
    }
    const otherIds = messages
      .filter((m) => m.sender_id !== user.id)
      .map((m) => m.id);
    const next = Array.from(new Set([...hiddenIds, ...otherIds]));
    setHiddenIds(next);
    localStorage.setItem(`chat_hidden_${conversationId}`, JSON.stringify(next));
    setConfirmClear(false);
    toast.success("Чат очищен");
  };

  const visibleMessages = useMemo(() => {
    if (!user) return [];
    return messages.filter((m) => {
      if (hiddenIds.includes(m.id)) return false;
      if (m.sender_id === user.id && m.deleted_for_sender) return false;
      return true;
    });
  }, [messages, user?.id, hiddenIds]);

  const formatTime = (iso: string) =>
    new Date(iso).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });

  const formatDateLabel = (iso: string) => {
    const d = new Date(iso);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);
    if (d.toDateString() === today.toDateString()) return "Сегодня";
    if (d.toDateString() === yesterday.toDateString()) return "Вчера";
    return d.toLocaleDateString("ru-RU", { day: "numeric", month: "long" });
  };

  // Group with date separators
  const grouped = useMemo(() => {
    const out: Array<{ type: "date"; label: string; key: string } | { type: "msg"; m: DBMessage }> = [];
    let lastDate = "";
    for (const m of visibleMessages) {
      const day = new Date(m.created_at).toDateString();
      if (day !== lastDate) {
        out.push({ type: "date", label: formatDateLabel(m.created_at), key: day });
        lastDate = day;
      }
      out.push({ type: "msg", m });
    }
    return out;
  }, [visibleMessages]);

  const renderFile = (m: DBMessage) => {
    if (!m.file_data || !m.file_type) return null;
    if (m.file_type.startsWith("image/")) {
      return (
        <button
          type="button"
          onClick={() => setLightbox(m.file_data!)}
          className="block mt-1 rounded-xl overflow-hidden border border-border/50 hover:opacity-90 transition-opacity"
        >
          <img
            src={m.file_data}
            alt={m.file_name || ""}
            className="max-w-[260px] max-h-[320px] object-cover"
            loading="lazy"
          />
        </button>
      );
    }
    return (
      <a
        href={m.file_data}
        download={m.file_name || "file"}
        className="flex items-center gap-2 mt-1 px-2.5 py-2 rounded-lg bg-background/40 hover:bg-background/60 transition-colors"
      >
        <div className="w-8 h-8 rounded-md bg-primary/20 flex items-center justify-center shrink-0">
          <Paperclip className="w-4 h-4" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium truncate">{m.file_name}</p>
          <p className="text-[10px] opacity-70">Нажмите, чтобы скачать</p>
        </div>
        <Download className="w-3.5 h-3.5 opacity-60" />
      </a>
    );
  };

  const noRecipient = !recipientId;
  const initials = recipientName.slice(0, 2).toUpperCase();

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md h-[100dvh] sm:h-[640px] flex flex-col p-0 gap-0 overflow-hidden sm:rounded-2xl">
          {/* Header */}
          <DialogHeader className="px-4 py-3 border-b border-border/60 bg-card/80 backdrop-blur-sm flex-row items-center justify-between space-y-0 shrink-0">
            <div className="flex items-center gap-3 min-w-0">
              <div className="relative shrink-0">
                <Avatar className="w-10 h-10 ring-2 ring-primary/20">
                  {recipientAvatar && <AvatarImage src={recipientAvatar} />}
                  <AvatarFallback className="bg-gradient-to-br from-primary/30 to-primary/10 text-primary font-semibold">
                    {initials}
                  </AvatarFallback>
                </Avatar>
                {!noRecipient && isRecipientOnline && (
                  <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-card" />
                )}
              </div>
              <div className="min-w-0">
                <DialogTitle className="text-base leading-tight truncate">
                  {recipientName}
                </DialogTitle>
                <p className="text-[11px] text-muted-foreground flex items-center gap-1">
                  {noRecipient ? (
                    "Демо-чат"
                  ) : isRecipientOnline ? (
                    <>
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      В сети
                    </>
                  ) : (
                    "Не в сети"
                  )}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 shrink-0 rounded-full"
                onClick={() => setCallOpen(true)}
                disabled={noRecipient}
                title="Позвонить через WhatsApp"
              >
                <Phone className="w-4 h-4" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0 rounded-full">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem
                    onClick={() => setConfirmClear(true)}
                    className="text-destructive focus:text-destructive"
                    disabled={noRecipient || messages.length === 0}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Очистить чат
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </DialogHeader>

          {/* Messages */}
          <ScrollArea
            className="flex-1 bg-gradient-to-b from-background via-background to-secondary/20"
            ref={scrollRef}
          >
            <div className="p-4 space-y-2">
              {noRecipient && (
                <p className="text-center text-muted-foreground text-sm py-12">
                  Откройте чат из карточки навыка или раздела «Сессии»
                </p>
              )}
              {!noRecipient && grouped.length === 0 && (
                <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                    <Send className="w-7 h-7 text-primary" />
                  </div>
                  <p className="text-sm text-muted-foreground max-w-[240px]">
                    Начните разговор — напишите первое сообщение, чтобы договориться об обмене
                  </p>
                </div>
              )}
              {grouped.map((item) => {
                if (item.type === "date") {
                  return (
                    <div key={"d-" + item.key} className="flex justify-center my-3">
                      <span className="text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-full bg-secondary/80 text-muted-foreground font-medium">
                        {item.label}
                      </span>
                    </div>
                  );
                }
                const m = item.m;
                const isMe = m.sender_id === user?.id;
                const isDeleted = m.deleted_for_all;
                const hasOnlyImage =
                  !m.text && m.file_type?.startsWith("image/");
                return (
                  <div
                    key={m.id}
                    className={`flex group ${isMe ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`flex items-end gap-1 max-w-[85%] ${
                        isMe ? "flex-row" : "flex-row-reverse"
                      }`}
                    >
                      {!isDeleted && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity shrink-0"
                            >
                              <MoreVertical className="w-3 h-3" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align={isMe ? "end" : "start"}>
                            <DropdownMenuItem onClick={() => deleteForMe(m)}>
                              Удалить у себя
                            </DropdownMenuItem>
                            {isMe && (
                              <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() => deleteForAll(m)}
                                  className="text-destructive focus:text-destructive"
                                >
                                  Удалить у всех
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                      <div
                        className={`relative ${
                          hasOnlyImage ? "p-1" : "px-3.5 py-2"
                        } shadow-sm ${
                          isMe
                            ? "bg-gradient-to-br from-primary to-primary/90 text-primary-foreground rounded-2xl rounded-br-md"
                            : "bg-card border border-border/60 text-card-foreground rounded-2xl rounded-bl-md"
                        } ${isDeleted ? "italic opacity-60" : ""}`}
                      >
                        {isDeleted ? (
                          <p className="text-sm">Сообщение удалено</p>
                        ) : (
                          <>
                            {renderFile(m)}
                            {m.text && (
                              <p className="text-sm whitespace-pre-wrap break-words leading-relaxed">
                                {m.text}
                              </p>
                            )}
                          </>
                        )}
                        <div
                          className={`flex items-center gap-1 mt-1 text-[10px] ${
                            hasOnlyImage ? "px-1.5 pb-0.5" : ""
                          } ${
                            isMe
                              ? "text-primary-foreground/75 justify-end"
                              : "text-muted-foreground justify-end"
                          }`}
                        >
                          <span>{formatTime(m.created_at)}</span>
                          {isMe && !isDeleted &&
                            (m.read_at ? (
                              <CheckCheck className="w-3.5 h-3.5" />
                            ) : (
                              <Check className="w-3.5 h-3.5" />
                            ))}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>

          {/* Pending file preview */}
          {pendingFile && (
            <div className="px-3 py-2 border-t border-border/60 bg-secondary/40 flex items-center gap-2.5 shrink-0">
              {pendingFile.type.startsWith("image/") ? (
                <img
                  src={pendingFile.data}
                  alt=""
                  className="w-12 h-12 rounded-lg object-cover border border-border/60"
                />
              ) : (
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Paperclip className="w-5 h-5 text-primary" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground truncate font-medium">
                  {pendingFile.name}
                </p>
                <p className="text-[11px] text-muted-foreground">
                  {pendingFile.sizeKb < 1024
                    ? `${pendingFile.sizeKb} КБ`
                    : `${(pendingFile.sizeKb / 1024).toFixed(1)} МБ`}
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 rounded-full"
                onClick={() => setPendingFile(null)}
              >
                <X className="w-3.5 h-3.5" />
              </Button>
            </div>
          )}

          {/* Emoji picker with categories */}
          {showEmoji && (
            <div className="border-t border-border/60 bg-card shrink-0">
              <Tabs value={emojiTab} onValueChange={setEmojiTab}>
                <TabsList className="w-full justify-start rounded-none bg-transparent border-b border-border/60 h-auto p-1 overflow-x-auto flex">
                  {Object.keys(EMOJI_CATEGORIES).map((cat) => (
                    <TabsTrigger
                      key={cat}
                      value={cat}
                      className="text-xs px-2.5 py-1 shrink-0 data-[state=active]:bg-secondary"
                    >
                      {cat}
                    </TabsTrigger>
                  ))}
                </TabsList>
                {Object.entries(EMOJI_CATEGORIES).map(([cat, list]) => (
                  <TabsContent key={cat} value={cat} className="m-0">
                    <div className="px-2 py-2 max-h-40 overflow-y-auto grid grid-cols-8 sm:grid-cols-10 gap-0.5">
                      {list.map((e, i) => (
                        <button
                          key={cat + i}
                          type="button"
                          onClick={() => {
                            setNewMessage((p) => p + e);
                            textareaRef.current?.focus();
                          }}
                          className="w-9 h-9 rounded-lg hover:bg-secondary text-xl transition-colors flex items-center justify-center"
                        >
                          {e}
                        </button>
                      ))}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </div>
          )}

          {/* Composer */}
          <div className="p-2.5 sm:p-3 border-t border-border/60 bg-card/80 backdrop-blur-sm shrink-0">
            <div className="flex gap-1.5 items-end">
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.doc,.docx,.txt,.zip,.xls,.xlsx,.ppt,.pptx"
                className="hidden"
                onChange={(e) => handleFileSelect(e, false)}
              />
              <input
                ref={imageInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleFileSelect(e, true)}
              />
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="shrink-0 h-9 w-9 rounded-full"
                    disabled={noRecipient || sending}
                  >
                    <Paperclip className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" side="top">
                  <DropdownMenuItem onClick={() => imageInputRef.current?.click()}>
                    <ImageIcon className="w-4 h-4 mr-2" />
                    Изображение
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => fileInputRef.current?.click()}>
                    <Paperclip className="w-4 h-4 mr-2" />
                    Файл
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button
                variant="ghost"
                size="icon"
                className="shrink-0 h-9 w-9 rounded-full"
                onClick={() => setShowEmoji((s) => !s)}
                disabled={noRecipient || sending}
              >
                <Smile className="w-4 h-4" />
              </Button>

              <textarea
                ref={textareaRef}
                placeholder={noRecipient ? "Чат недоступен" : "Сообщение..."}
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={1}
                className="flex-1 resize-none rounded-2xl border border-input bg-background px-4 py-2 text-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 max-h-[120px]"
                disabled={noRecipient || sending}
                maxLength={4000}
              />
              <Button
                onClick={handleSend}
                size="icon"
                className="shrink-0 h-9 w-9 rounded-full bg-primary hover:bg-primary/90"
                disabled={
                  noRecipient || sending || (!newMessage.trim() && !pendingFile)
                }
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <VideoCallDialog
        open={callOpen}
        onOpenChange={setCallOpen}
        partnerName={recipientName}
        skillTitle="общение"
      />

      {/* Image lightbox */}
      <Dialog open={!!lightbox} onOpenChange={(o) => !o && setLightbox(null)}>
        <DialogContent className="max-w-3xl p-0 bg-transparent border-0 shadow-none">
          {lightbox && (
            <img
              src={lightbox}
              alt=""
              className="w-full h-auto max-h-[85vh] object-contain rounded-lg"
            />
          )}
        </DialogContent>
      </Dialog>

      <AlertDialog open={confirmClear} onOpenChange={setConfirmClear}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Очистить весь чат?</AlertDialogTitle>
            <AlertDialogDescription>
              Ваши сообщения будут удалены у всех участников. Сообщения собеседника будут скрыты только у вас.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction
              onClick={clearChat}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Очистить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default ChatDialog;
