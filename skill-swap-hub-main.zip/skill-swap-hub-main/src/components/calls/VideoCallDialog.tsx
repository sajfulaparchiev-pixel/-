import { Phone, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { toast } from "sonner";

interface VideoCallDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  partnerName: string;
  skillTitle: string;
  partnerPhone?: string;
}

const sanitizePhone = (raw: string) => raw.replace(/[^\d+]/g, "").replace(/^\+?/, "");

const VideoCallDialog = ({ open, onOpenChange, partnerName, skillTitle, partnerPhone }: VideoCallDialogProps) => {
  const [phone, setPhone] = useState(partnerPhone || "");

  const openWhatsApp = (action: "chat" | "call") => {
    const clean = sanitizePhone(phone);
    if (!clean || clean.length < 7) {
      toast.error("Введите корректный номер телефона (с кодом страны)");
      return;
    }
    const msg = encodeURIComponent(`Привет, ${partnerName}! Хочу обсудить «${skillTitle}» через Skillflow.`);
    const url = action === "call"
      ? `https://wa.me/${clean}`
      : `https://wa.me/${clean}?text=${msg}`;
    window.open(url, "_blank", "noopener,noreferrer");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Связаться через WhatsApp</DialogTitle>
          <DialogDescription>
            Введите номер телефона {partnerName} с кодом страны (например, +79991234567).
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="wa-phone">Номер телефона</Label>
            <Input
              id="wa-phone"
              inputMode="tel"
              placeholder="+7 999 123-45-67"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              autoFocus
            />
            <p className="text-xs text-muted-foreground">
              WhatsApp откроется в новой вкладке. Звонок начинается из приложения WhatsApp.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Button variant="outline" className="flex-1 gap-2" onClick={() => openWhatsApp("chat")}>
              <MessageCircle className="w-4 h-4" />
              Открыть чат
            </Button>
            <Button variant="hero" className="flex-1 gap-2" onClick={() => openWhatsApp("call")}>
              <Phone className="w-4 h-4" />
              Позвонить
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VideoCallDialog;
