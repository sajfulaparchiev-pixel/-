import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Home, Search, Calendar, User, Plus } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

const MobileNav = () => {
  const location = useLocation();
  const { t } = useLanguage();
  
  const navItems = [
    { path: "/feed", icon: Home, label: t("feed") },
    { path: "/search", icon: Search, label: t("search") },
    { path: "/add-skill", icon: Plus, label: t("add"), isMain: true },
    { path: "/sessions", icon: Calendar, label: t("sessions") },
    { path: "/profile", icon: User, label: t("profile") },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-lg border-t border-border safe-area-inset-bottom">
      <div className="flex items-center justify-around py-2 px-4">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          
          if (item.isMain) {
            return (
              <Link key={item.path} to={item.path} className="relative -mt-6">
                <motion.div
                  whileTap={{ scale: 0.9 }}
                  className="w-14 h-14 rounded-full gradient-hero flex items-center justify-center shadow-elevated"
                >
                  <Icon className="w-6 h-6 text-primary-foreground" />
                </motion.div>
              </Link>
            );
          }

          return (
            <Link key={item.path} to={item.path} className="flex flex-col items-center gap-1 py-2 px-3">
              <motion.div
                whileTap={{ scale: 0.9 }}
                className={`p-1 rounded-lg transition-colors ${isActive ? "text-primary" : "text-muted-foreground"}`}
              >
                <Icon className="w-5 h-5" />
              </motion.div>
              <span className={`text-xs font-medium ${isActive ? "text-primary" : "text-muted-foreground"}`}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default MobileNav;
