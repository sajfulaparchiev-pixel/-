import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Camera, Upload, Loader2 } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

// Built-in default avatars using gradient backgrounds and emoji
const defaultAvatars = [
  { id: "avatar-1", emoji: "🦊", bg: "bg-orange-100 dark:bg-orange-900/30" },
  { id: "avatar-2", emoji: "🐱", bg: "bg-yellow-100 dark:bg-yellow-900/30" },
  { id: "avatar-3", emoji: "🐻", bg: "bg-amber-100 dark:bg-amber-900/30" },
  { id: "avatar-4", emoji: "🦉", bg: "bg-purple-100 dark:bg-purple-900/30" },
  { id: "avatar-5", emoji: "🐸", bg: "bg-green-100 dark:bg-green-900/30" },
  { id: "avatar-6", emoji: "🦋", bg: "bg-blue-100 dark:bg-blue-900/30" },
  { id: "avatar-7", emoji: "🐙", bg: "bg-pink-100 dark:bg-pink-900/30" },
  { id: "avatar-8", emoji: "🦄", bg: "bg-violet-100 dark:bg-violet-900/30" },
  { id: "avatar-9", emoji: "🐼", bg: "bg-gray-100 dark:bg-gray-800/30" },
  { id: "avatar-10", emoji: "🦁", bg: "bg-yellow-100 dark:bg-yellow-900/30" },
  { id: "avatar-11", emoji: "🐨", bg: "bg-slate-100 dark:bg-slate-800/30" },
  { id: "avatar-12", emoji: "🐯", bg: "bg-orange-100 dark:bg-orange-900/30" },
];

const MAX_SIZE_PX = 128;
const MAX_FILE_MB = 2;

function compressImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (file.size > MAX_FILE_MB * 1024 * 1024) {
      reject(new Error(`Файл слишком большой (макс. ${MAX_FILE_MB}МБ)`));
      return;
    }
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = MAX_SIZE_PX;
      canvas.height = MAX_SIZE_PX;
      const ctx = canvas.getContext("2d")!;
      // Crop to square from center
      const size = Math.min(img.width, img.height);
      const sx = (img.width - size) / 2;
      const sy = (img.height - size) / 2;
      ctx.drawImage(img, sx, sy, size, size, 0, 0, MAX_SIZE_PX, MAX_SIZE_PX);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/webp", 0.7));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Не удалось загрузить изображение"));
    };
    img.src = url;
  });
}

interface AvatarSelectorProps {
  currentAvatar?: string;
  userInitials: string;
  onSelect: (avatarId: string) => void;
}

const AvatarSelector = ({ currentAvatar, userInitials, onSelect }: AvatarSelectorProps) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(currentAvatar || "");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSelect = (avatarId: string) => {
    setSelected(avatarId);
    onSelect(avatarId);
    setOpen(false);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const dataUrl = await compressImage(file);
      setSelected(dataUrl);
      onSelect(dataUrl);
      setOpen(false);
    } catch (err: any) {
      toast({ title: t("error"), description: err.message, variant: "destructive" });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const currentDefault = defaultAvatars.find((a) => a.id === currentAvatar);
  const isCustomImage = currentAvatar && currentAvatar.startsWith("data:");

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <div className="relative group cursor-pointer">
          <Avatar className="w-24 h-24 border-4 border-primary/20">
            {currentDefault ? (
              <AvatarFallback className={cn("text-4xl", currentDefault.bg)}>
                {currentDefault.emoji}
              </AvatarFallback>
            ) : isCustomImage ? (
              <AvatarImage src={currentAvatar} alt="Avatar" />
            ) : (
              <AvatarFallback className="bg-primary/10 text-primary text-2xl font-bold">
                {userInitials}
              </AvatarFallback>
            )}
          </Avatar>
          <div className="absolute inset-0 rounded-full bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <Camera className="w-6 h-6 text-white" />
          </div>
        </div>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{t("chooseAvatar")}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          {/* Upload button */}
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />
            <Button
              variant="outline"
              className="w-full gap-2"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
            >
              {uploading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Upload className="w-4 h-4" />
              )}
              Загрузить фото
            </Button>
            <p className="text-xs text-muted-foreground mt-1 text-center">
              Макс. {MAX_FILE_MB}МБ · Сжимается до {MAX_SIZE_PX}×{MAX_SIZE_PX}
            </p>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center"><span className="w-full border-t" /></div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">или</span>
            </div>
          </div>

          <p className="text-sm text-muted-foreground">{t("defaultAvatars")}</p>
          <div className="grid grid-cols-4 gap-3">
            {defaultAvatars.map((avatar) => (
              <button
                key={avatar.id}
                onClick={() => handleSelect(avatar.id)}
                className={cn(
                  "w-16 h-16 rounded-full flex items-center justify-center text-2xl transition-all hover:scale-110",
                  avatar.bg,
                  selected === avatar.id
                    ? "ring-3 ring-primary ring-offset-2 ring-offset-background"
                    : "hover:ring-2 hover:ring-primary/30"
                )}
              >
                {avatar.emoji}
              </button>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export { defaultAvatars };
export default AvatarSelector;
