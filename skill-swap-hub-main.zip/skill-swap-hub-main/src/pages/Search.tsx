import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import Header from "@/components/layout/Header";
import MobileNav from "@/components/layout/MobileNav";
import SkillCard from "@/components/skills/SkillCard";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search as SearchIcon, Sparkles, SlidersHorizontal } from "lucide-react";
import { useSkills } from "@/contexts/SkillsContext";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useAuth } from "@/contexts/AuthContext";

const popularSkills = [
  "React",
  "Python",
  "Дизайн",
  "Английский",
  "Гитара",
  "Фотография",
  "Маркетинг",
  "Йога",
];

const categories = [
  "Все",
  "Программирование",
  "Дизайн",
  "Музыка",
  "Языки",
  "Фитнес",
  "Бизнес",
  "Искусство",
  "Кулинария",
  "Фотография",
  "Маркетинг",
  "Образование",
  "Видео и монтаж",
  "Психология",
  "Танцы",
  "Рукоделие",
  "Финансы",
  "Наука",
  "Здоровье",
  "Путешествия",
  "Игры и киберспорт",
  "Литература",
  "Ремонт и DIY",
  "Другое",
];

const Search = () => {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Все");
  const [sortBy, setSortBy] = useState("newest");
  const [filterOpen, setFilterOpen] = useState(false);
  const { skills, searchSkills } = useSkills();
  const { user } = useAuth();

  const results = useMemo(() => {
    let res = searchSkills(query, category);
    if (sortBy === "rating") {
      res = [...res].sort((a, b) => b.user.rating - a.user.rating);
    } else if (sortBy === "popular") {
      res = [...res].sort((a, b) => b.user.sessionsCount - a.user.sessionsCount);
    }
    return res;
  }, [query, category, sortBy, skills]);

  return (
    <div className="min-h-screen bg-background pb-24 md:pb-0">
      <Header />

      <main className="container mx-auto px-4 pt-24 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="text-center mb-8">
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
              Поиск навыков
            </h1>
            <p className="text-muted-foreground">
              Найди именно то, что хочешь изучить
            </p>
          </div>

          {/* Search */}
          <div className="flex gap-2 mb-6">
            <div className="relative flex-1">
              <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Искать по названию, описанию, категории..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="pl-12 h-14 text-base rounded-2xl border-border/50 bg-secondary/50 focus:bg-background"
              />
            </div>
            <Sheet open={filterOpen} onOpenChange={setFilterOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="h-14 w-14 rounded-2xl">
                  <SlidersHorizontal className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Фильтры</SheetTitle>
                </SheetHeader>
                <div className="space-y-3 mt-6">
                  <Label className="text-base font-medium">Сортировка</Label>
                  <RadioGroup value={sortBy} onValueChange={setSortBy} className="space-y-2">
                    <Label htmlFor="s-newest" className="flex items-center gap-3 p-3 rounded-lg border cursor-pointer hover:bg-secondary/50">
                      <RadioGroupItem value="newest" id="s-newest" />
                      <span>Сначала новые</span>
                    </Label>
                    <Label htmlFor="s-popular" className="flex items-center gap-3 p-3 rounded-lg border cursor-pointer hover:bg-secondary/50">
                      <RadioGroupItem value="popular" id="s-popular" />
                      <span>По числу сессий</span>
                    </Label>
                    <Label htmlFor="s-rating" className="flex items-center gap-3 p-3 rounded-lg border cursor-pointer hover:bg-secondary/50">
                      <RadioGroupItem value="rating" id="s-rating" />
                      <span>По рейтингу</span>
                    </Label>
                  </RadioGroup>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Categories */}
          <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide">
            {categories.map((c) => (
              <Badge
                key={c}
                variant={category === c ? "default" : "secondary"}
                className={`cursor-pointer whitespace-nowrap px-4 py-2 text-sm font-medium transition-all hover:scale-105 ${
                  category === c ? "gradient-hero border-transparent" : ""
                }`}
                onClick={() => setCategory(c)}
              >
                {c}
              </Badge>
            ))}
          </div>

          {/* Popular */}
          {!query && (
            <div className="mb-8">
              <h2 className="text-base font-semibold text-foreground mb-3">
                Популярные запросы
              </h2>
              <div className="flex flex-wrap gap-2">
                {popularSkills.map((skill) => (
                  <Badge
                    key={skill}
                    variant="secondary"
                    className="cursor-pointer px-4 py-2 text-sm hover:bg-primary hover:text-primary-foreground transition-colors"
                    onClick={() => setQuery(skill)}
                  >
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Results */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-accent" />
              <h2 className="text-lg font-semibold text-foreground">
                {query || category !== "Все" ? "Результаты" : "Все навыки"}
              </h2>
              <Badge variant="secondary" className="ml-auto">
                {results.length}
              </Badge>
            </div>

            {results.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                Ничего не найдено. Попробуйте другой запрос.
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 gap-4">
                {results.map((skill, i) => (
                  <SkillCard
                    key={skill.id}
                    skill={skill}
                    index={i}
                    isOwner={skill.userId === user?.id}
                  />
                ))}
              </div>
            )}
          </div>
        </motion.div>
      </main>

      <MobileNav />
    </div>
  );
};

export default Search;
