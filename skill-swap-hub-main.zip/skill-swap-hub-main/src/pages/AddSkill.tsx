import { useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import Header from "@/components/layout/Header";
import MobileNav from "@/components/layout/MobileNav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Plus, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSkills } from "@/contexts/SkillsContext";

const categories = [
  "Программирование",
  "Дизайн",
  "Музыка",
  "Языки",
  "Фитнес",
  "Фотография",
  "Маркетинг",
  "Бизнес",
  "Искусство",
  "Кулинария",
  "Спорт",
  "Танцы",
  "Видеомонтаж",
  "Письмо и копирайтинг",
  "Психология",
  "Финансы",
  "Наука и образование",
  "Ремёсла",
  "Другое",
];

const MAX_DESC_WORDS = 350;
const countWords = (s: string) => s.trim().split(/\s+/).filter(Boolean).length;

const AddSkill = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { addSkill } = useSkills();
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    format: "",
    duration: "",
  });

  const [wantedSkill, setWantedSkill] = useState("");
  const [wantedSkills, setWantedSkills] = useState<string[]>([]);

  const descWords = countWords(formData.description);
  const wordsOver = descWords > MAX_DESC_WORDS;

  const addWantedSkill = () => {
    const v = wantedSkill.trim();
    if (v && !wantedSkills.includes(v)) {
      setWantedSkills([...wantedSkills, v]);
      setWantedSkill("");
    }
  };

  const removeWantedSkill = (skill: string) => {
    setWantedSkills(wantedSkills.filter((s) => s !== skill));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!formData.title.trim()) {
      toast({ title: "Заполните название", variant: "destructive" });
      return;
    }
    if (!formData.description.trim()) {
      toast({ title: "Добавьте описание", variant: "destructive" });
      return;
    }
    if (wordsOver) {
      toast({ title: "Описание слишком длинное", description: `Максимум ${MAX_DESC_WORDS} слов`, variant: "destructive" });
      return;
    }
    if (!formData.category) {
      toast({ title: "Выберите категорию", variant: "destructive" });
      return;
    }
    if (!formData.format) {
      toast({ title: "Выберите формат занятий", variant: "destructive" });
      return;
    }
    const duration = parseInt(formData.duration);
    if (!duration || duration < 15 || duration > 180) {
      toast({ title: "Укажите длительность от 15 до 180 минут", variant: "destructive" });
      return;
    }
    // Wanted skills required
    let wanted = wantedSkills;
    const pending = wantedSkill.trim();
    if (pending && !wanted.includes(pending)) wanted = [...wanted, pending];
    if (wanted.length === 0) {
      toast({ title: "Укажите, что хотите взамен", description: "Это обязательное поле — добавьте хотя бы один навык", variant: "destructive" });
      return;
    }

    setSubmitting(true);
    try {
      await addSkill({
        title: formData.title.trim(),
        description: formData.description.trim(),
        category: formData.category,
        level: "beginner",
        format: formData.format as "online" | "offline" | "both",
        duration,
        wantedSkills: wanted,
      });
      toast({ title: "Навык добавлен!", description: "Ваш навык виден в ленте сообщества" });
      navigate("/feed");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24 md:pb-0">
      <Header />

      <main className="container mx-auto px-4 pt-24 max-w-2xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <button
            onClick={() => navigate(-1)}
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Назад
          </button>

          <div className="mb-6 sm:mb-8">
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
              Добавить навык
            </h1>
            <p className="text-muted-foreground text-sm sm:text-base">
              Расскажите о навыке, которым хотите поделиться
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6" noValidate>
            <div className="space-y-2">
              <Label htmlFor="title">Название навыка *</Label>
              <Input
                id="title"
                placeholder="Например: React и TypeScript разработка"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="h-12"
                maxLength={100}
                required
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="description">Описание *</Label>
                <span className={`text-xs ${wordsOver ? "text-destructive" : "text-muted-foreground"}`}>
                  {descWords} / {MAX_DESC_WORDS} слов
                </span>
              </div>
              <Textarea
                id="description"
                placeholder="Опишите, чему вы можете научить и какой у вас опыт..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className={`min-h-[140px] resize-none ${wordsOver ? "border-destructive" : ""}`}
                required
              />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Категория *</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Выберите категорию" />
                  </SelectTrigger>
                  <SelectContent className="max-h-[300px]">
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Формат *</Label>
                <Select
                  value={formData.format}
                  onValueChange={(value) => setFormData({ ...formData, format: value })}
                >
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Формат занятий" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="online">Онлайн</SelectItem>
                    <SelectItem value="offline">Офлайн</SelectItem>
                    <SelectItem value="both">Любой</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="duration">Длительность (мин) *</Label>
              <Input
                id="duration"
                type="number"
                placeholder="60"
                min="15"
                max="180"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                className="h-12"
                required
              />
            </div>

            <div className="space-y-3">
              <Label>Что хотите изучить взамен? *</Label>
              <div className="flex gap-2">
                <Input
                  placeholder="Например: Дизайн интерфейсов"
                  value={wantedSkill}
                  onChange={(e) => setWantedSkill(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addWantedSkill();
                    }
                  }}
                  className="h-12"
                  maxLength={50}
                />
                <Button type="button" variant="outline" size="icon" className="h-12 w-12 shrink-0" onClick={addWantedSkill}>
                  <Plus className="w-5 h-5" />
                </Button>
              </div>
              {wantedSkills.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {wantedSkills.map((skill) => (
                    <Badge key={skill} variant="secondary" className="gap-1 pr-1">
                      {skill}
                      <button
                        type="button"
                        onClick={() => removeWantedSkill(skill)}
                        className="ml-1 p-0.5 rounded-full hover:bg-foreground/10"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
              <p className="text-xs text-muted-foreground">
                Добавьте хотя бы один навык, который хотите получить взамен.
              </p>
            </div>

            <div className="pt-4">
              <Button type="submit" variant="hero" size="lg" className="w-full" disabled={submitting}>
                {submitting ? "Публикация..." : "Опубликовать навык"}
              </Button>
            </div>
          </form>
        </motion.div>
      </main>

      <MobileNav />
    </div>
  );
};

export default AddSkill;
