import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import Header from "@/components/layout/Header";
import MobileNav from "@/components/layout/MobileNav";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, BookOpen, Check, X, MessageCircle, Inbox, Send } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import ChatDialog from "@/components/chat/ChatDialog";

interface Exchange {
  id: string;
  from_user_id: string;
  to_user_id: string;
  skill_id: string;
  skill_title: string;
  from_user_name: string;
  to_user_name: string;
  status: "pending" | "accepted" | "rejected";
  created_at: string;
}

const Sessions = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const { t } = useLanguage();
  const [exchanges, setExchanges] = useState<Exchange[]>([]);
  const [loading, setLoading] = useState(true);
  const [chat, setChat] = useState<{ open: boolean; name: string; id: string } | null>(null);

  const fetchExchanges = async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("exchanges")
      .select("*")
      .or(`from_user_id.eq.${user.id},to_user_id.eq.${user.id}`)
      .order("created_at", { ascending: false });
    setExchanges((data as Exchange[]) || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchExchanges();
    if (!user) return;
    const channel = supabase
      .channel("exchanges-watch")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "exchanges" },
        () => fetchExchanges()
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  const respond = async (ex: Exchange, status: "accepted" | "rejected") => {
    const { error } = await supabase
      .from("exchanges")
      .update({ status })
      .eq("id", ex.id);
    if (error) {
      toast({ title: "Ошибка", description: error.message, variant: "destructive" });
      return;
    }
    // Notify initiator
    await supabase.from("notifications").insert({
      user_id: ex.from_user_id,
      type: status === "accepted" ? "exchange_accepted" : "exchange_rejected",
      title: status === "accepted" ? "Запрос принят!" : "Запрос отклонён",
      message:
        status === "accepted"
          ? `${ex.to_user_name} принял(а) запрос на обмен «${ex.skill_title}». Можете начать общение.`
          : `${ex.to_user_name} отклонил(а) запрос на обмен «${ex.skill_title}».`,
      from_user_name: ex.to_user_name,
      related_skill_id: ex.skill_id,
    });
    toast({
      title: status === "accepted" ? "Принято" : "Отклонено",
      description: status === "accepted" ? "Откройте чат, чтобы договориться о деталях" : undefined,
    });
  };

  const incoming = exchanges.filter((e) => e.to_user_id === user?.id && e.status === "pending");
  const outgoing = exchanges.filter((e) => e.from_user_id === user?.id && e.status === "pending");
  const accepted = exchanges.filter((e) => e.status === "accepted");
  const archived = exchanges.filter((e) => e.status === "rejected");

  const renderExchange = (ex: Exchange, type: "incoming" | "outgoing" | "accepted" | "archived") => {
    const partnerName = ex.from_user_id === user?.id ? ex.to_user_name : ex.from_user_name;
    const partnerId = ex.from_user_id === user?.id ? ex.to_user_id : ex.from_user_id;
    return (
      <motion.div
        key={ex.id}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-card rounded-2xl border border-border/50 p-4 sm:p-5"
      >
        <div className="flex items-start justify-between gap-3 mb-3 flex-wrap">
          <div className="min-w-0 flex-1">
            <h3 className="font-semibold text-foreground truncate">{ex.skill_title}</h3>
            <Link
              to={`/user/${partnerId}`}
              className="text-sm text-muted-foreground hover:text-primary"
            >
              {type === "incoming" ? "От: " : type === "outgoing" ? "Кому: " : "Партнёр: "}
              {partnerName}
            </Link>
          </div>
          <span className="text-xs text-muted-foreground">
            {new Date(ex.created_at).toLocaleDateString("ru-RU", { day: "numeric", month: "short" })}
          </span>
        </div>

        {type === "incoming" && (
          <div className="flex gap-2">
            <Button size="sm" className="flex-1" onClick={() => respond(ex, "accepted")}>
              <Check className="w-4 h-4 mr-1" /> Принять
            </Button>
            <Button size="sm" variant="outline" className="flex-1" onClick={() => respond(ex, "rejected")}>
              <X className="w-4 h-4 mr-1" /> Отклонить
            </Button>
          </div>
        )}

        {type === "outgoing" && (
          <p className="text-sm text-muted-foreground italic">Ожидает ответа…</p>
        )}

        {type === "accepted" && (
          <Button
            size="sm"
            variant="hero"
            className="w-full"
            onClick={() => setChat({ open: true, name: partnerName, id: partnerId })}
          >
            <MessageCircle className="w-4 h-4 mr-2" /> Открыть чат
          </Button>
        )}

        {type === "archived" && (
          <p className="text-sm text-muted-foreground">Запрос отклонён</p>
        )}
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen bg-background pb-24 md:pb-0">
      <Header />

      <main className="container mx-auto px-4 pt-24 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="mb-6 sm:mb-8">
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">{t("mySessions")}</h1>
            <p className="text-muted-foreground text-sm sm:text-base">{t("manageYourSessions")}</p>
          </div>

          <Tabs defaultValue="incoming" className="space-y-6">
            <TabsList className="w-full justify-start bg-secondary/50 p-1 rounded-xl overflow-x-auto">
              <TabsTrigger value="incoming" className="rounded-lg gap-1">
                <Inbox className="w-4 h-4" /> Входящие
                {incoming.length > 0 && (
                  <span className="ml-1 px-1.5 rounded-full bg-primary text-primary-foreground text-xs">
                    {incoming.length}
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="outgoing" className="rounded-lg gap-1">
                <Send className="w-4 h-4" /> Отправленные
              </TabsTrigger>
              <TabsTrigger value="active" className="rounded-lg gap-1">
                <Calendar className="w-4 h-4" /> Активные
              </TabsTrigger>
              <TabsTrigger value="archive" className="rounded-lg">Архив</TabsTrigger>
            </TabsList>

            <TabsContent value="incoming" className="space-y-3">
              {loading ? (
                <p className="text-center py-8 text-muted-foreground">Загрузка…</p>
              ) : incoming.length === 0 ? (
                <div className="text-center py-12">
                  <Inbox className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-medium text-foreground mb-2">Нет входящих запросов</h3>
                  <p className="text-muted-foreground text-sm">Когда кто-то предложит обмен — он появится здесь</p>
                </div>
              ) : (
                incoming.map((e) => renderExchange(e, "incoming"))
              )}
            </TabsContent>

            <TabsContent value="outgoing" className="space-y-3">
              {outgoing.length === 0 ? (
                <div className="text-center py-12">
                  <Send className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-medium text-foreground mb-2">Нет отправленных запросов</h3>
                  <p className="text-muted-foreground text-sm mb-4">Найдите интересный навык и предложите обмен</p>
                  <Button variant="hero" asChild>
                    <Link to="/feed">Найти навыки</Link>
                  </Button>
                </div>
              ) : (
                outgoing.map((e) => renderExchange(e, "outgoing"))
              )}
            </TabsContent>

            <TabsContent value="active" className="space-y-3">
              {accepted.length === 0 ? (
                <div className="text-center py-12">
                  <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-medium text-foreground mb-2">Нет активных обменов</h3>
                  <p className="text-muted-foreground text-sm">Принятые запросы появятся здесь</p>
                </div>
              ) : (
                accepted.map((e) => renderExchange(e, "accepted"))
              )}
            </TabsContent>

            <TabsContent value="archive" className="space-y-3">
              {archived.length === 0 ? (
                <p className="text-center py-12 text-muted-foreground">Архив пуст</p>
              ) : (
                archived.map((e) => renderExchange(e, "archived"))
              )}
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>

      {chat && (
        <ChatDialog
          open={chat.open}
          onOpenChange={(o) => setChat(o ? chat : null)}
          recipientName={chat.name}
          recipientId={chat.id}
        />
      )}

      <MobileNav />
    </div>
  );
};

export default Sessions;
